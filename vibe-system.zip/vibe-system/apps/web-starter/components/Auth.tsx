'use client';
import { signInWithPopup, signOut, User } from 'firebase/auth';
import { auth, googleProvider } from '@/lib/firebase';
import { Button } from '@vibe/ui';
import { useEffect, useState } from 'react';

export function AuthButton() {
  const [user, setUser] = useState<User | null>(null);
  const [isMock, setIsMock] = useState(false);

  useEffect(() => {
    if (!auth) {
        setIsMock(true);
        return;
    }
    return auth.onAuthStateChanged((u) => setUser(u));
  }, []);

  const handleLogin = async () => {
    if (!auth || !googleProvider) {
        alert("Demo Mode: Firebase keys are missing/mocked. Imagine you are logged in!");
        // Simulate login for UI
        setUser({ displayName: "Sandenn (Demo)", email: "demo@example.com" } as User);
        return;
    }
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
      alert("Login failed. Check console.");
    }
  };

  const handleLogout = () => {
      if (!auth) {
          setUser(null);
          return;
      }
      signOut(auth);
  }

  if (user) {
    return (
      <div className="flex items-center gap-4">
        <span className="text-sm text-zinc-400">Signed in as {user.displayName}</span>
        <Button onClick={handleLogout}>Sign Out</Button>
      </div>
    );
  }

  return <Button onClick={handleLogin}>{isMock ? "Sign In (Demo)" : "Sign In with Google"}</Button>;
}
