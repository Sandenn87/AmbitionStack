'use client';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ArrowLeft } from "lucide-react";
import Link from 'next/link';

const meetingsByCategory = [
  { name: 'Sales', value: 4 },
  { name: 'PM', value: 12 },
  { name: 'Client Support', value: 8 },
  { name: 'Emergency', value: 2 },
  { name: 'Finance', value: 1 },
];

const timeSpentData = [
  { name: 'You', hours: 24 },
  { name: 'John Doe', hours: 18 },
  { name: 'Jane Smith', hours: 12 },
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function ReportsPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white p-8">
       <Link href="/dashboard" className="flex items-center text-zinc-500 hover:text-white mb-6">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
      </Link>
      <h1 className="text-3xl font-bold mb-8">Reports & Analytics</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800 h-96">
          <h3 className="text-lg font-semibold mb-6">Meetings by Category</h3>
          <ResponsiveContainer width="100%" height="80%">
            <PieChart>
              <Pie
                data={meetingsByCategory}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {meetingsByCategory.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 text-xs text-zinc-400">
            {meetingsByCategory.map((entry, index) => (
               <span key={entry.name} style={{ color: COLORS[index % COLORS.length] }}>• {entry.name}</span>
            ))}
          </div>
        </div>

        <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800 h-96">
          <h3 className="text-lg font-semibold mb-6">Time Spent in Meetings (Hours)</h3>
          <ResponsiveContainer width="100%" height="80%">
             <BarChart data={timeSpentData}>
                 <XAxis dataKey="name" stroke="#52525b" />
                 <YAxis stroke="#52525b" />
                 <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} />
                 <Bar dataKey="hours" fill="#3b82f6" radius={[4, 4, 0, 0]} />
             </BarChart>
          </ResponsiveContainer>
        </div>

      </div>
    </div>
  );
}
