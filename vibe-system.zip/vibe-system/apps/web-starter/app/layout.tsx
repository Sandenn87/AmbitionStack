import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Link from "next/link";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Vibe System - Consultant Dashboard",
  description: "AI-Powered Consultant Workflow",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-zinc-950 text-white`}
      >
        <div className="flex min-h-screen">
          <nav className="w-64 border-r border-zinc-800 bg-zinc-900/50 p-6 flex flex-col gap-4 hidden md:flex">
             <div className="font-bold text-xl mb-6 bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">Vibe Console</div>
             <Link href="/dashboard" className="text-zinc-400 hover:text-white transition">Dashboard</Link>
             <Link href="/meetings" className="text-zinc-400 hover:text-white transition">Meetings</Link>
             <Link href="/reports" className="text-zinc-400 hover:text-white transition">Reports</Link>
          </nav>
          <main className="flex-1">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
