'use client';
import { Button } from "@vibe/ui";
import { useState } from "react";
import { ArrowLeft, CheckCircle, Circle, Upload } from "lucide-react";
import Link from "next/link";
import { useParams } from 'next/navigation';

export default function MeetingDetail() {
  const params = useParams();
  const [actions, setActions] = useState([
    { id: 1, text: "Send proposal to client", status: "open" },
    { id: 2, text: "Schedule follow-up call", status: "done" }
  ]);

  const handleSync = (actionId: number) => {
    alert(`Synced action ${actionId} to Microsoft To-Do!`);
  };

  const handleTeamsCreate = () => {
    alert("Created Teams Channel: 'Sales - TechCorp'\nPDF Transcript uploaded.");
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white p-8">
      <Link href="/dashboard" className="flex items-center text-zinc-500 hover:text-white mb-6">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900/50 p-8 rounded-2xl border border-zinc-800">
            <h1 className="text-3xl font-bold mb-2">Consultation with TechCorp</h1>
            <div className="flex gap-4 text-sm text-zinc-400">
              <span>Oct 24, 2023</span>
              <span>•</span>
              <span>45 Minutes</span>
              <span>•</span>
              <span className="text-blue-400">Sales</span>
            </div>
            
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Transcript Summary</h3>
              <p className="text-zinc-300 leading-relaxed">
                Client expressed interest in the cloud migration package. Key concerns identified around security compliance (SOC2) and downtime during the transition.
                <br /><br />
                <strong>Wins:</strong> Client budget approved.<br />
                <strong>Issues:</strong> Timeline is tight (needs Q3 launch).
              </p>
            </div>
          </div>

          <div className="bg-zinc-900/50 p-8 rounded-2xl border border-zinc-800">
             <div className="flex justify-between items-center mb-6">
               <h3 className="text-xl font-semibold">Action Items</h3>
               <Button className="bg-zinc-800 hover:bg-zinc-700">Add Action</Button>
             </div>
             <div className="space-y-3">
               {actions.map((action) => (
                 <div key={action.id} className="flex items-center justify-between p-4 bg-zinc-950 rounded-lg border border-zinc-900">
                   <div className="flex items-center gap-3">
                     {action.status === 'done' ? <CheckCircle className="text-green-500 w-5 h-5"/> : <Circle className="text-zinc-600 w-5 h-5"/>}
                     <span className={action.status === 'done' ? "line-through text-zinc-600" : ""}>{action.text}</span>
                   </div>
                   <button onClick={() => handleSync(action.id)} className="text-xs text-blue-400 hover:underline">
                     Sync to To-Do
                   </button>
                 </div>
               ))}
             </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
            <h3 className="font-semibold mb-4">Collaboration</h3>
            <Button onClick={handleTeamsCreate} className="w-full mb-3 flex items-center justify-center gap-2">
              <Upload className="w-4 h-4" /> Create Teams Channel
            </Button>
            <p className="text-xs text-zinc-500 text-center">
              Creates channel & uploads PDF scope.
            </p>
          </div>
          
          <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
            <h3 className="font-semibold mb-4">Participants</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">S</div>
                <span>Sandenn (You)</span>
              </div>
               <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center">J</div>
                <span className="text-zinc-400">John Client</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
