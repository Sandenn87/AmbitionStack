'use client';
import { Button } from "@vibe/ui";
import Link from 'next/link';

const meetings = [
  { id: '1', title: 'Consultation with TechCorp', date: '2023-10-24', category: 'Sales', duration: 45 },
  { id: '2', title: 'Project Alpha Weekly', date: '2023-10-23', category: 'PM', duration: 30 },
  { id: '3', title: 'Emergency Sync', date: '2023-10-23', category: 'Emergency', duration: 15 },
];

export default function MeetingsPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white p-8">
      <Link href="/dashboard" className="text-zinc-500 hover:text-white mb-6 inline-block">
        &larr; Back to Dashboard
      </Link>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Meetings</h1>
        <Button>Import from Fireflies</Button>
      </div>

      <div className="bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden">
        <table className="w-full text-left text-sm text-zinc-400">
          <thead className="text-xs uppercase bg-zinc-900/80 text-zinc-500">
            <tr>
              <th className="px-6 py-4 font-medium">Title</th>
              <th className="px-6 py-4 font-medium">Category</th>
              <th className="px-6 py-4 font-medium">Date</th>
              <th className="px-6 py-4 font-medium">Duration</th>
              <th className="px-6 py-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {meetings.map((meeting) => (
              <tr key={meeting.id} className="hover:bg-zinc-900/50 transition">
                <td className="px-6 py-4 font-medium text-white">{meeting.title}</td>
                <td className="px-6 py-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900/50 text-blue-200">
                    {meeting.category}
                  </span>
                </td>
                <td className="px-6 py-4">{meeting.date}</td>
                <td className="px-6 py-4">{meeting.duration} min</td>
                <td className="px-6 py-4 text-right">
                  <Link href={`/meetings/${meeting.id}`} className="text-blue-400 hover:text-blue-300">
                    View
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
