'use client';
import { Button } from "@vibe/ui";
import { AuthButton } from "@/components/Auth";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const mockData = [
  { name: 'Sales', meetings: 4 },
  { name: 'PM', meetings: 12 },
  { name: 'Emergency', meetings: 2 },
  { name: 'Finance', meetings: 1 },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white p-8">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
            Consultant Dashboard
          </h1>
          <p className="text-zinc-400">Manage your transcripts, actions, and teams.</p>
        </div>
        <AuthButton />
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stats */}
        <div className="md:col-span-2 grid grid-cols-2 gap-4">
          <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
            <h3 className="text-zinc-500 mb-2">Total Meetings</h3>
            <p className="text-4xl font-bold">19</p>
          </div>
          <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
            <h3 className="text-zinc-500 mb-2">Pending Actions</h3>
            <p className="text-4xl font-bold text-yellow-500">7</p>
          </div>
          
          <div className="col-span-2 bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800 h-64">
             <h3 className="text-zinc-500 mb-4">Meetings by Category</h3>
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={mockData}>
                 <XAxis dataKey="name" stroke="#52525b" />
                 <YAxis stroke="#52525b" />
                 <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} />
                 <Bar dataKey="meetings" fill="#3b82f6" radius={[4, 4, 0, 0]} />
               </BarChart>
             </ResponsiveContainer>
          </div>
        </div>

        {/* Action Items */}
        <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
          <h2 className="text-xl font-semibold mb-4">Actions</h2>
          <div className="space-y-4">
             {[1, 2, 3].map((i) => (
               <div key={i} className="flex items-start gap-3 p-3 bg-zinc-950 rounded-lg border border-zinc-900">
                 <div className="w-4 h-4 mt-1 rounded-sm border border-zinc-600"></div>
                 <div>
                   <p className="text-sm font-medium">Update client scope for Project Alpha</p>
                   <p className="text-xs text-zinc-500">Due Tomorrow • Assignee: Me</p>
                 </div>
               </div>
             ))}
          </div>
          <div className="mt-4 pt-4 border-t border-zinc-800">
             <Button className="w-full">Sync from Fireflies</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
