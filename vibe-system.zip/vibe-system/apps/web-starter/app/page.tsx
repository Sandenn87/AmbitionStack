"use client";

import { Button } from "@vibe/ui";
import { useState } from "react";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    setIsGenerating(true);
    // Simulate generation delay
    setTimeout(() => {
      setIsGenerating(false);
      alert(`Vibe System received: "${prompt}"\n(This is a demo. Implementation needed!)`);
      setPrompt("");
    }, 1000);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-900 text-white p-8">
      <main className="flex max-w-2xl flex-col items-center gap-8 text-center w-full">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
            Vibe Coding System
          </h1>
          <p className="text-lg text-zinc-400">
            What do you want to build?
          </p>
        </div>

        <form onSubmit={handleSubmit} className="w-full max-w-lg flex gap-2">
          <input 
            type="text" 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe a feature..." 
            className="flex-1 rounded-lg border border-zinc-700 bg-zinc-950 px-4 py-2 text-white placeholder-zinc-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <Button disabled={isGenerating}>
            {isGenerating ? "Thinking..." : "Generate"}
          </Button>
        </form>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 w-full mt-8">
          <div className="p-6 rounded-2xl border border-zinc-800 bg-zinc-950/50 hover:bg-zinc-900 transition flex flex-col items-start gap-3">
            <h2 className="text-xl font-semibold">🤖 AI Core</h2>
            <p className="text-sm text-zinc-500 text-left">
              Import <code>@vibe/ui</code> to add streaming intelligence to your app.
            </p>
          </div>
          <div className="p-6 rounded-2xl border border-zinc-800 bg-zinc-950/50 hover:bg-zinc-900 transition flex flex-col items-start gap-3">
            <h2 className="text-xl font-semibold">🎨 UI Kit</h2>
            <p className="text-sm text-zinc-500 text-left">
              Import <code>@vibe/ui</code> for shared components like this button:
            </p>
            <Button>Shared Button</Button>
          </div>
        </div>
      </main>
    </div>
  );
}
