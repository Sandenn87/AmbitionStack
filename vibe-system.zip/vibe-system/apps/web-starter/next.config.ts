import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@vibe/ui"],
};

export default nextConfig;
